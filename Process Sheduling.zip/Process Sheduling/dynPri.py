#!/usr/bin/env python
# -*- coding: utf-8 -*-
class DynPri:
	def __init__(self):
		self.ret__M = 0
		self.res__M = 0
		self.esp__M = 0
#retorno = step(process executou) - step(process exc = 0)
	def work(self, process):
		step = 0
		ret = 0.0
		res = 0.0
		esp = 0.0
		while len(process) > 0:
			for x in range(0, len(process), 1):
				if process[x].arr == step:
					process[x].set_prt(len(process)+1)
			#ordena por prioridades	da mais alta para a menor
			process.sort(key=lambda x: x.prt, reverse=True)
			i = 0
			for x in range(1,(len(process)-1),1):
				if process[0].prt > process[x].prt:
					break
				else: #pega o que tiver menor indice
					if process[x].idt < process[i].idt:
						i = x
						break
			if process[i].start_exc == -1:
				process[i].set_start_exc(step)
				res += (step - process[i].arr)
			process[i].dec_prt()
			process[i].dec_exc(1)
			#print("nova prioridade: "+str(process[i].prt))
			if process[i].exc == 0:
				#print("processo: "+str(process[i].idt)+" Finalizou em "+str(step))
				ret += (step - process[i].arr)+1
				#print("Valeu: "+str((step - process[i].arr)+1))
				del process[i]
				for x in range(0, len(process), 1):
				#encontra os processos que ainda não receberam prioridades
					if (process[x].prt > 0):
						process[x].inc_prt()
						#print("incrementou o: "+str(process[x].idt))
						esp += 1	
				step += 1
				#print("\n")
				continue
			#incrementa as prioridades dos outros
			for x in range(0, len(process), 1):
				#encontra os processos que ainda não receberam prioridades
				if (process[x].prt > 0 and x != i):
					process[x].inc_prt()
					#print("incrementou o: "+str(process[x].idt))
					esp += 1	
			step += 1
			#print("\n")	
		return (ret, res, esp)			